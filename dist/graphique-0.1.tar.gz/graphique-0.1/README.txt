graphique

This is a python package for making charting in plotly easier and quicker.

Contributing:

Please do!
