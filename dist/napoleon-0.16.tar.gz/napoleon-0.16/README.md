# Napoleon

[![CircleCI](https://circleci.com/gh/mitchelllisle/napoleon.svg?style=svg)](https://circleci.com/gh/mitchelllisle/napoleon)

This is a simple Python package designd to make plotting with plotly quicker and easier with some sensible defaults.

### Installation
`pip install napoleon`

### Getting Started
...
